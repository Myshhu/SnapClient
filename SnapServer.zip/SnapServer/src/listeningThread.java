import com.example.myshh.snapclient.MessageObject;

import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.stream.ImageOutputStream;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class listeningThread extends Thread {

    private Socket clientSocket;
    private ObjectInputStream inFromClient;
    private byte[] buffer;
    private List<Socket> allClients;

    listeningThread(Socket clientSocket, List<Socket> allClients) {
        try {
            this.clientSocket = clientSocket;
            this.allClients = allClients;
            inFromClient = new ObjectInputStream(new BufferedInputStream(clientSocket.getInputStream()));
            buffer = new byte[1];
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        while (true) {
            MessageObject messageObject;
            try {
                messageObject = (MessageObject) inFromClient.readObject();
                saveImage(messageObject.imageBytes);
                sendToAll(messageObject);
            } catch (Exception e) {
                e.printStackTrace();
                allClients.remove(clientSocket);
                break;
            }
        }
    }


    private void saveImage(byte[] data) {
        String timeStampWithMinutes = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String timeStamp = new SimpleDateFormat("yyyyMMdd").format(new Date());

        File mainDir = new File("images");
        if(!mainDir.exists()){
            mainDir.mkdir();
        }
        System.out.println(mainDir.getPath());
        File timeStampDir = new File(mainDir.getPath() + File.separator + timeStamp);
        if (!timeStampDir.exists()) {
            timeStampDir.mkdir();
        }
        File mediaFile = new File(timeStampDir + File.separator + "IMG_" + timeStampWithMinutes + ".jpg");
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(mediaFile);
            fos.write(data);
            fos.close();
            System.out.println("Saved image");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void sendToAll(MessageObject messageObject) {
        System.out.println("-----");
        for (Socket a : allClients) {
            try {
                //Create new stream for every socket and send object
                ObjectOutputStream outToClient = new ObjectOutputStream(new BufferedOutputStream(a.getOutputStream()));
                messageObject.imageBytes = compressImage(messageObject.imageBytes);
                outToClient.writeObject(messageObject);
                outToClient.flush();
                System.out.println("Sent object");
            } catch (Exception e) {
                e.printStackTrace();
                allClients.remove(a);
            }
        }
    }

    private byte[] compressImage(byte[] imageData) throws Exception {
        ByteArrayOutputStream os = new ByteArrayOutputStream();

        Iterator<ImageWriter> writers = ImageIO.getImageWritersByFormatName("jpg");
        ImageWriter writer = (ImageWriter) writers.next();

        ImageOutputStream ios = ImageIO.createImageOutputStream(os);
        writer.setOutput(ios);

        ImageWriteParam param = writer.getDefaultWriteParam();

        param.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
        param.setCompressionQuality(0.2f);  // Change the quality value you prefer
        BufferedImage image = ImageIO.read(new ByteArrayInputStream(imageData));
        writer.write(null, new IIOImage(image, null, null), param);

        byte[] compressedImage = os.toByteArray();

        os.close();
        ios.close();
        writer.dispose();

        return compressedImage;
    }
}
