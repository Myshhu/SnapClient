import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class mainClass {

    public static void main(String[] args){
        List<Socket> clientSockets = new ArrayList<>();
        new Thread(()->{
            try {
                ServerSocket serverSocket = new ServerSocket(50005);
                while (true) {
                    System.out.println("Waiting for accept");
                    Socket clientSocket = serverSocket.accept();
                    System.out.println("Connected with " + clientSocket.getInetAddress());
                    clientSockets.add(clientSocket);
                    new listeningThread(clientSocket, clientSockets).start();
                    System.out.println("After thread start");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
    }
}
